﻿namespace ftec.projetoweb.TrabalhoPedidos.api.Models
{
    public class PedidoModel
    {
        public PedidoModel()
        {
            this.Id = Guid.Empty;
            this.UsuarioId = Guid.Empty;
            this.ProdutosModel = new List<ProdutoModel>();
            this.DataPedido = DateTime.MinValue;
        }

        public Guid Id { get; set; }
        public Guid UsuarioId { get; set; }
        public List<ProdutoModel> ProdutosModel { get; set; }
        public DateTime DataPedido {  get; set; }
    }
}
